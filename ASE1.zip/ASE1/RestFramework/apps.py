from django.apps import AppConfig


class RestframeworkConfig(AppConfig):
    name = 'RestFramework'
