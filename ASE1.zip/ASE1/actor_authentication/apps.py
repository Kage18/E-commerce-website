from django.apps import AppConfig


class ActorAuthenticationConfig(AppConfig):
    name = 'actor_authentication'
