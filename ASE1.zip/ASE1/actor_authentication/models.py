from django.db import models
from customer.models import CustomerProfile
from vendor.models import VendorProfile
# Create your models here.
