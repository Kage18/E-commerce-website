from django.contrib import admin
from customer.models import CustomerProfile

# Register your models here.

admin.site.register(CustomerProfile)

